import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase, LineChart, BookOpen, ArrowRight } from 'lucide-react';

const Home = () => {
  const navigate = useNavigate();

  const features = [
    {
      id: 'start-business',
      title: 'Start Business',
      description: 'Step-by-step guidance to launch your business with confidence',
      icon: <Briefcase className="w-6 h-6 text-purple-600" />,
      path: '/start-business',
      color: 'bg-purple-100',
      buttonColor: 'bg-purple-600 hover:bg-purple-700'
    },
    {
      id: 'financial-planning',
      title: 'Financial Planning & Investment',
      description: 'Smart tools to manage finances and grow your wealth',
      icon: <LineChart className="w-6 h-6 text-green-600" />,
      path: '/financial-planning',
      color: 'bg-green-100',
      buttonColor: 'bg-green-600 hover:bg-green-700'
    },
    {
      id: 'learning-hub',
      title: 'Learning Hub & Community',
      description: 'Learn from experts and connect with fellow entrepreneurs',
      icon: <BookOpen className="w-6 h-6 text-indigo-600" />,
      path: '/learning-hub',
      color: 'bg-indigo-100',
      buttonColor: 'bg-indigo-600 hover:bg-indigo-700'
    }
  ];

  const successStories = [
    {
      name: "Priya Sharma",
      business: "Organic Food Startup",
      quote: "Nachiyar helped me transform my home kitchen into a thriving organic food business with 20+ employees.",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
    },
    {
      name: "Lakshmi Venkatesh",
      business: "Handcrafted Jewelry",
      quote: "The business setup guide saved me months of research and helped me secure a government loan for my jewelry business.",
      image: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-purple-700 to-purple-900 rounded-2xl p-8 mb-12 text-white">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Welcome to Nachiyar</h1>
        <p className="text-lg md:text-xl mb-6 max-w-2xl">
          Your complete toolkit for entrepreneurial success. Build, grow, and lead your business with confidence.
        </p>
        <div className="bg-white/20 p-4 rounded-lg inline-block">
          <p className="italic">
            "The future belongs to those who believe in the beauty of their dreams." — Eleanor Roosevelt
          </p>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        {features.map((feature) => (
          <div 
            key={feature.id}
            className={`${feature.color} rounded-xl p-6 shadow-md transition-transform duration-300 hover:scale-105`}
          >
            <div className="flex items-center mb-4">
              <div className="bg-white p-3 rounded-full mr-4">
                {feature.icon}
              </div>
              <h2 className="text-xl font-bold">{feature.title}</h2>
            </div>
            <p className="text-gray-700 mb-6">{feature.description}</p>
            <button 
              onClick={() => navigate(feature.path)}
              className={`flex items-center ${feature.buttonColor} text-white px-4 py-2 rounded-lg transition duration-300`}
            >
              Get Started
              <ArrowRight className="ml-2 w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {/* Success Stories */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Success Stories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {successStories.map((story, index) => (
            <div key={index} className="bg-white rounded-xl shadow-md overflow-hidden flex flex-col md:flex-row">
              <img 
                src={story.image} 
                alt={story.name} 
                className="w-full md:w-1/3 h-48 md:h-auto object-cover"
              />
              <div className="p-6">
                <h3 className="font-bold text-lg mb-1">{story.name}</h3>
                <p className="text-purple-600 mb-3">{story.business}</p>
                <p className="italic text-gray-600">"{story.quote}"</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-gradient-to-r from-green-100 to-green-200 rounded-xl p-8 text-center">
        <h2 className="text-2xl font-bold mb-4 text-gray-800">Ready to start your entrepreneurial journey?</h2>
        <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
          Join thousands of women who have transformed their business ideas into reality with Nachiyar.
        </p>
        <button 
          onClick={() => navigate('/start-business')}
          className="bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-lg transition duration-300"
        >
          Start Your Business Now
        </button>
      </div>
    </div>
  );
};

export default Home;