import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Globe } from 'lucide-react';

const Welcome = () => {
  const navigate = useNavigate();
  const [language, setLanguage] = useState('english');
  
  const handleContinue = () => {
    // Save language preference to localStorage
    localStorage.setItem('language', language);
    navigate('/home');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-purple-100 to-white">
      <div className="max-w-md w-full bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="bg-purple-700 p-6 text-center">
          <div className="inline-flex justify-center items-center w-16 h-16 rounded-full bg-white mb-4">
            <Shield className="w-8 h-8 text-purple-700" />
          </div>
          <h1 className="text-3xl font-bold text-white">Nachiyar</h1>
          <p className="text-purple-100 mt-2">Empowering women to lead, succeed, and break barriers</p>
        </div>
        
        <div className="p-6">
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Welcome to Nachiyar</h2>
            <p className="text-gray-600">
              Named after the legendary Velu Nachiyar, India's first queen to fight against British colonial power, 
              this app is designed to empower modern women entrepreneurs with practical tools and guidance.
            </p>
          </div>
          
          <div className="mb-8">
            <h3 className="text-lg font-medium text-gray-800 mb-3">Select your preferred language</h3>
            <div className="flex items-center space-x-2 mb-4">
              <Globe className="w-5 h-5 text-purple-600" />
              <select 
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="block w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="english">English</option>
                <option value="hindi">हिंदी (Hindi)</option>
                <option value="tamil">தமிழ் (Tamil)</option>
                <option value="telugu">తెలుగు (Telugu)</option>
                <option value="bengali">বাংলা (Bengali)</option>
              </select>
            </div>
          </div>
          
          <button
            onClick={handleContinue}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 px-4 rounded-md transition duration-300 ease-in-out transform hover:scale-105"
          >
            Continue
          </button>
          
          <p className="text-center text-sm text-gray-500 mt-6">
            By continuing, you agree to our Terms of Service and Privacy Policy
          </p>
        </div>
      </div>
    </div>
  );
};

export default Welcome;