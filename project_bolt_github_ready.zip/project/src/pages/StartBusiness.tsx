import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, Coffee, Scissors, ShoppingBag, Briefcase, Check } from 'lucide-react';

const StartBusiness = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [selectedSector, setSelectedSector] = useState('');
  const [selectedModel, setSelectedModel] = useState('');

  const businessSectors = [
    { 
      id: 'food', 
      name: 'Food & Beverages', 
      icon: <Coffee className="w-6 h-6" />,
      description: 'Restaurants, catering, packaged foods, bakeries, and more'
    },
    { 
      id: 'handicrafts', 
      name: 'Handicrafts', 
      icon: <Scissors className="w-6 h-6" />,
      description: 'Handmade products, textiles, jewelry, home decor, and art'
    },
    { 
      id: 'retail', 
      name: 'Retail Store', 
      icon: <ShoppingBag className="w-6 h-6" />,
      description: 'Clothing, accessories, electronics, groceries, and more'
    },
    { 
      id: 'service', 
      name: 'Service Business', 
      icon: <Briefcase className="w-6 h-6" />,
      description: 'Consulting, beauty, education, healthcare, and tech services'
    }
  ];

  const businessModels = [
    { 
      id: 'b2b', 
      name: 'B2B (Business to Business)', 
      description: 'Selling products or services to other businesses',
      examples: 'Wholesale suppliers, business consultants, corporate caterers'
    },
    { 
      id: 'b2c', 
      name: 'B2C (Business to Consumer)', 
      description: 'Selling directly to individual customers',
      examples: 'Retail stores, restaurants, personal services'
    },
    { 
      id: 'online', 
      name: 'Online Business', 
      description: 'Operating primarily through digital channels',
      examples: 'E-commerce stores, digital services, online courses'
    },
    { 
      id: 'hybrid', 
      name: 'Hybrid Model', 
      description: 'Combining physical and online presence',
      examples: 'Brick-and-click retail, omnichannel businesses'
    }
  ];

  const handleSectorSelect = (sectorId) => {
    setSelectedSector(sectorId);
    setStep(2);
  };

  const handleModelSelect = (modelId) => {
    setSelectedModel(modelId);
    // Save selections to localStorage for persistence
    localStorage.setItem('selectedSector', sectorId);
    localStorage.setItem('selectedModel', modelId);
    // Navigate to the business setup page with the selected sector and model
    navigate(`/business-setup/${selectedSector}/${modelId}`);
  };

  const handleBack = () => {
    if (step === 2) {
      setStep(1);
      setSelectedModel('');
    } else {
      navigate('/home');
    }
  };

  const quotes = [
    "The question isn't who's going to let me; it's who's going to stop me. — Ayn Rand",
    "Don't be intimidated by what you don't know. That can be your greatest strength. — Sara Blakely",
    "If you don't build your dream, someone else will hire you to help them build theirs. — Dhirubhai Ambani",
    "The way to get started is to quit talking and begin doing. — Walt Disney"
  ];

  const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Progress Indicator */}
      <div className="mb-8">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <div className={`flex flex-col items-center ${step >= 1 ? 'text-purple-600' : 'text-gray-400'}`}>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-purple-600 text-white' : 'bg-gray-200'}`}>
              {step > 1 ? <Check className="w-5 h-5" /> : 1}
            </div>
            <span className="text-sm mt-2">Select Sector</span>
          </div>
          <div className={`flex-1 h-1 mx-2 ${step >= 2 ? 'bg-purple-600' : 'bg-gray-200'}`}></div>
          <div className={`flex flex-col items-center ${step >= 2 ? 'text-purple-600' : 'text-gray-400'}`}>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-purple-600 text-white' : 'bg-gray-200'}`}>
              2
            </div>
            <span className="text-sm mt-2">Select Model</span>
          </div>
          <div className="flex-1 h-1 mx-2 bg-gray-200"></div>
          <div className="flex flex-col items-center text-gray-400">
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-gray-200">
              3
            </div>
            <span className="text-sm mt-2">Setup Guide</span>
          </div>
        </div>
      </div>

      {/* Page Title */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Start Your Business</h1>
        <p className="text-gray-600 mt-2">Let's build your entrepreneurial journey step by step</p>
      </div>

      {/* Quote Card */}
      <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded mb-8">
        <p className="italic text-purple-800">{randomQuote}</p>
      </div>

      {/* Step 1: Select Business Sector */}
      {step === 1 && (
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-6">Select Your Business Sector</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {businessSectors.map((sector) => (
              <div 
                key={sector.id}
                onClick={() => handleSectorSelect(sector.id)}
                className={`border rounded-lg p-4 cursor-pointer transition-all duration-300 hover:shadow-md ${
                  selectedSector === sector.id ? 'border-purple-500 bg-purple-50' : 'border-gray-200'
                }`}
              >
                <div className="flex items-center">
                  <div className={`p-3 rounded-full mr-4 ${
                    selectedSector === sector.id ? 'bg-purple-100' : 'bg-gray-100'
                  }`}>
                    {sector.icon}
                  </div>
                  <div>
                    <h3 className="font-medium">{sector.name}</h3>
                    <p className="text-sm text-gray-600">{sector.description}</p>
                  </div>
                  <ChevronRight className="ml-auto w-5 h-5 text-gray-400" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Step 2: Select Business Model */}
      {step === 2 && (
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-2">Select Your Business Model</h2>
          <p className="text-gray-600 mb-6">
            For your {businessSectors.find(s => s.id === selectedSector)?.name} business
          </p>
          <div className="space-y-4">
            {businessModels.map((model) => (
              <div 
                key={model.id}
                onClick={() => handleModelSelect(model.id)}
                className={`border rounded-lg p-4 cursor-pointer transition-all duration-300 hover:shadow-md ${
                  selectedModel === model.id ? 'border-purple-500 bg-purple-50' : 'border-gray-200'
                }`}
              >
                <h3 className="font-medium">{model.name}</h3>
                <p className="text-sm text-gray-600 mt-1">{model.description}</p>
                <div className="mt-2 bg-gray-50 p-2 rounded text-sm">
                  <span className="font-medium">Examples:</span> {model.examples}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Navigation Buttons */}
      <div className="flex justify-between">
        <button
          onClick={handleBack}
          className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-300"
        >
          Back
        </button>
        {step === 1 && selectedSector && (
          <button
            onClick={() => setStep(2)}
            className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors duration-300"
          >
            Continue
          </button>
        )}
      </div>
    </div>
  );
};

export default StartBusiness;