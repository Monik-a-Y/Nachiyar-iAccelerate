import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Shield, Menu, X, User, Bell } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  
  // Don't show navbar on welcome page
  if (location.pathname === '/') {
    return null;
  }

  const navLinks = [
    { name: 'Home', path: '/home' },
    { name: 'Start Business', path: '/start-business' },
    { name: 'Financial Planning', path: '/financial-planning' },
    { name: 'Learning Hub', path: '/learning-hub' }
  ];

  return (
    <nav className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/home" className="flex items-center space-x-2">
            <div className="bg-purple-600 p-2 rounded-full">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl text-purple-700">Nachiyar</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-medium transition-colors duration-300 ${
                  location.pathname === link.path
                    ? 'text-purple-700 border-b-2 border-purple-500'
                    : 'text-gray-600 hover:text-purple-600'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          {/* User Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <button className="text-gray-500 hover:text-purple-600">
              <Bell className="w-5 h-5" />
            </button>
            <div className="flex items-center space-x-2 text-gray-700 hover:text-purple-600 cursor-pointer">
              <User className="w-5 h-5" />
              <span className="text-sm font-medium">My Profile</span>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-500 hover:text-purple-600 focus:outline-none"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="container mx-auto px-4 py-3 space-y-3">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`block py-2 text-sm font-medium ${
                  location.pathname === link.path
                    ? 'text-purple-700'
                    : 'text-gray-600 hover:text-purple-600'
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                {link.name}
              </Link>
            ))}
            <div className="border-t pt-3 mt-3">
              <div className="flex items-center space-x-2 text-gray-700 py-2">
                <User className="w-5 h-5" />
                <span className="text-sm font-medium">My Profile</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;