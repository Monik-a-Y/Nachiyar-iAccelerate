import React from 'react';
import { Shield, Facebook, Twitter, Instagram, Linkedin, Mail } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Footer = () => {
  const location = useLocation();
  
  // Don't show footer on welcome page
  if (location.pathname === '/') {
    return null;
  }

  return (
    <footer className="bg-gray-50 border-t">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-purple-600 p-2 rounded-full">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl text-purple-700">Nachiyar</span>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              Empowering women entrepreneurs with the tools and knowledge to build successful businesses.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-purple-600">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-600">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-600">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-600">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/home" className="text-sm text-gray-600 hover:text-purple-600">Home</Link>
              </li>
              <li>
                <Link to="/start-business" className="text-sm text-gray-600 hover:text-purple-600">Start Business</Link>
              </li>
              <li>
                <Link to="/financial-planning" className="text-sm text-gray-600 hover:text-purple-600">Financial Planning</Link>
              </li>
              <li>
                <Link to="/learning-hub" className="text-sm text-gray-600 hover:text-purple-600">Learning Hub</Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-sm text-gray-600 hover:text-purple-600">Business Templates</a>
              </li>
              <li>
                <a href="#" className="text-sm text-gray-600 hover:text-purple-600">Success Stories</a>
              </li>
              <li>
                <a href="#" className="text-sm text-gray-600 hover:text-purple-600">Government Schemes</a>
              </li>
              <li>
                <a href="#" className="text-sm text-gray-600 hover:text-purple-600">Financial Calculators</a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Contact Us</h3>
            <div className="flex items-center space-x-2 mb-2">
              <Mail className="w-4 h-4 text-gray-400" />
              <a href="mailto:support@nachiyar.com" className="text-sm text-gray-600 hover:text-purple-600">support@nachiyar.com</a>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              We'd love to hear from you! Send us your questions or feedback.
            </p>
            <button className="bg-purple-600 hover:bg-purple-700 text-white text-sm px-4 py-2 rounded-lg transition duration-300">
              Contact Support
            </button>
          </div>
        </div>

        <div className="border-t mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-500 mb-4 md:mb-0">
            © {new Date().getFullYear()} Nachiyar. All rights reserved.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="text-sm text-gray-500 hover:text-purple-600">Privacy Policy</a>
            <a href="#" className="text-sm text-gray-500 hover:text-purple-600">Terms of Service</a>
            <a href="#" className="text-sm text-gray-500 hover:text-purple-600">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;